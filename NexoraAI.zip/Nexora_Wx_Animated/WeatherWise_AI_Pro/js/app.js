const $=id=>document.getElementById(id);
const map=L.map('map',{zoomControl:false}).setView([-5.420,105.260],6);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; OpenStreetMap contributors'}).addTo(map);
L.control.zoom({position:'topright'}).addTo(map);
let marker=L.marker([-5.420,105.260]).addTo(map), selected={name:'Bandar Lampung',lat:-5.420,lon:105.260},weather=null,chart=null,activeLayer='wind',animationOn=!window.matchMedia('(prefers-reduced-motion: reduce)').matches,particles=[],locationAccuracy=null;
const canvas=$('windCanvas'),ctx=canvas.getContext('2d');
function resizeCanvas(){let r=canvas.getBoundingClientRect();canvas.width=Math.max(1,Math.floor(r.width*devicePixelRatio));canvas.height=Math.max(1,Math.floor(r.height*devicePixelRatio));ctx.setTransform(devicePixelRatio,0,0,devicePixelRatio,0,0);particles=[];for(let i=0;i<140;i++)particles.push({x:Math.random()*r.width,y:Math.random()*r.height,life:Math.random()*100});}
function animate(){let w=canvas.clientWidth,h=canvas.clientHeight;ctx.clearRect(0,0,w,h);if(animationOn&&activeLayer==='wind'){let s=weather?.current?.wind_speed_10m||12,d=(weather?.current?.wind_direction_10m||225)*Math.PI/180,vx=Math.sin(d)*(.6+s/28),vy=-Math.cos(d)*(.6+s/28);ctx.lineWidth=1.2;for(let p of particles){ctx.strokeStyle=`rgba(36,125,245,${.2+(p.life%45)/110})`;ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(p.x+vx*9,p.y+vy*9);ctx.stroke();p.x+=vx*1.6;p.y+=vy*1.6;p.life++;if(p.x<0||p.x>w||p.y<0||p.y>h||p.life>160){p.x=Math.random()*w;p.y=Math.random()*h;p.life=0;}}}if(!document.hidden)requestAnimationFrame(animate);}
document.addEventListener('visibilitychange',()=>{if(!document.hidden)requestAnimationFrame(animate)});
window.addEventListener('resize',()=>{resizeCanvas();map.invalidateSize();});setTimeout(()=>map.invalidateSize(),250);resizeCanvas();animate();
const desc=c=>({0:'Cerah',1:'Cerah berawan',2:'Berawan sebagian',3:'Mendung',45:'Berkabut',48:'Kabut tebal',51:'Gerimis ringan',53:'Gerimis',55:'Gerimis lebat',61:'Hujan ringan',63:'Hujan sedang',65:'Hujan lebat',80:'Hujan lokal',81:'Hujan lokal sedang',82:'Hujan lokal lebat',95:'Badai petir'})[c]||'Cuaca berubah-ubah';
const icon=c=>c===0?'☀':([1,2].includes(c)?'🌤':([3,45,48].includes(c)?'☁':([51,53,55,61,63,65,80,81,82].includes(c)?'🌧':(c>=95?'⛈':'🌦'))));
const time=t=>new Date(t).toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'});
function updateWindCompass(degrees,speed){if(!Number.isFinite(Number(degrees)))return;const dirs=['Utara','Timur Laut','Timur','Tenggara','Selatan','Barat Daya','Barat','Barat Laut'];const short=['U','TL','T','TG','S','BD','B','BL'];const ix=Math.round((((Number(degrees)%360)+360)%360)/45)%8;const needle=document.querySelector('.compass-needle');if(needle)needle.style.transform=`translate(-50%,-50%) rotate(${Number(degrees)}deg)`;$('windDirectionText').textContent=`${dirs[ix]} (${short[ix]})`;$('windDirectionDegree').textContent=`${Math.round(Number(degrees))}° · ${Math.round(Number(speed)||0)} km/j`;}
const WEATHER_CACHE_TTL=10*60*1000;
function readCache(key){try{const v=JSON.parse(localStorage.getItem(key)||'null');return v&&Date.now()-v.savedAt<WEATHER_CACHE_TTL?v.data:null}catch(_){return null}}
function readStaleCache(key){try{return JSON.parse(localStorage.getItem(key)||'null')?.data||null}catch(_){return null}}
function writeCache(key,data){try{localStorage.setItem(key,JSON.stringify({savedAt:Date.now(),data}))}catch(_){}}
function wttrCode(code){const n=Number(code);if(n===113)return 0;if([116,119,122,143,248,260].includes(n))return n===116?2:3;if([176,263,266,293,296,299,302,305,308,311,314,317,350,353,356,359,362,365,374,377].includes(n))return 61;if([200,386,389,392,395].includes(n))return 95;return 2}
async function fetchFallbackWeather(){
 const lat=Number(selected.lat).toFixed(3),lon=Number(selected.lon).toFixed(3);
 const r=await fetch(`https://wttr.in/${lat},${lon}?format=j1`,{signal:AbortSignal.timeout(10000)});if(!r.ok)throw Error(`Fallback cuaca HTTP ${r.status}`);const d=await r.json();const cc=d.current_condition?.[0],days=d.weather||[];if(!cc)throw Error('Data fallback tidak lengkap');
 const hourly=[];for(const day of days){for(const h of (day.hourly||[])){const date=day.date;const hh=String(h.time||'0').padStart(4,'0');hourly.push({time:`${date}T${hh.slice(0,2)}:${hh.slice(2)||'00'}:00`,temperature_2m:Number(h.tempC),precipitation_probability:Number(h.chanceofrain||0),precipitation:Number(h.precipMM||0),wind_speed_10m:Number(h.windspeedKmph||0),weather_code:wttrCode(h.weatherCode)});}}
 const current={time:new Date().toISOString().slice(0,16),temperature_2m:Number(cc.temp_C),relative_humidity_2m:Number(cc.humidity),apparent_temperature:Number(cc.FeelsLikeC),is_day:1,precipitation:Number(cc.precipMM||0),weather_code:wttrCode(cc.weatherCode),wind_speed_10m:Number(cc.windspeedKmph),wind_direction_10m:Number(cc.winddirDegree||0)};
 return {current,hourly:{time:hourly.map(x=>x.time),temperature_2m:hourly.map(x=>x.temperature_2m),precipitation_probability:hourly.map(x=>x.precipitation_probability),precipitation:hourly.map(x=>x.precipitation),wind_speed_10m:hourly.map(x=>x.wind_speed_10m),weather_code:hourly.map(x=>x.weather_code)},_source:'wttr.in fallback'};
}
async function loadWeather(){
 $('updatedAt').textContent='Memperbarui cuaca...';const cacheKey=`ww-weather-${selected.lat.toFixed(2)}-${selected.lon.toFixed(2)}`;
 try{const r=await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${selected.lat}&longitude=${selected.lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,wind_speed_10m,wind_direction_10m&hourly=temperature_2m,precipitation_probability,precipitation,wind_speed_10m,weather_code&forecast_days=2&timezone=auto`,{signal:AbortSignal.timeout(12000)});if(!r.ok)throw Error(`Open-Meteo HTTP ${r.status}`);weather=await r.json();weather._source='Open-Meteo';writeCache(cacheKey,weather);renderWeatherCards();
 }catch(e){console.warn('Open-Meteo gagal, mencoba sumber cadangan:',e);try{weather=await fetchFallbackWeather();writeCache(cacheKey,weather);renderWeatherCards();$('updatedAt').textContent='Data cadangan · wttr.in';$('insightText').textContent+=' Sumber data cadangan digunakan karena layanan utama tidak merespons.';}
 catch(fallbackError){const cached=readStaleCache(cacheKey);if(cached?.current&&cached?.hourly){weather=cached;renderWeatherCards();$('updatedAt').textContent='Data tersimpan · koneksi API terbatas';}
 else{$('updatedAt').textContent=`Data online gagal (${e.message||'koneksi'})`; $('condition').textContent='Data cuaca online belum tersedia';$('conditionShort').textContent='Coba Perbarui';$('insightText').textContent='Layanan cuaca sedang membatasi permintaan atau koneksi gagal. Data tidak dibuat-buat; coba kembali sebentar lagi.';console.error('Sumber utama dan cadangan gagal:',e,fallbackError);}}
 }
}
function renderWeatherCards(){if(!weather?.current||!weather?.hourly)return;let c=weather.current;updateWindCompass(c.wind_direction_10m,c.wind_speed_10m);
$('locationName').textContent=selected.name;$('locationSub').textContent=`${selected.lat.toFixed(5)}°, ${selected.lon.toFixed(5)}°${locationAccuracy!==null?` · GPS ±${Math.round(locationAccuracy)} m`:''}`;$('mapLocation').textContent=selected.name;$('mapCoords').textContent=`${selected.lat.toFixed(3)}°, ${selected.lon.toFixed(3)}°`;$('coordinates').textContent=`${selected.lat.toFixed(2)}°`; $('currentTemp').textContent=`${Math.round(c.temperature_2m)}°`;$('weatherIcon').textContent=icon(c.weather_code);$('condition').textContent=desc(c.weather_code);$('conditionShort').textContent=desc(c.weather_code);$('currentFeels').textContent=`${Math.round(c.apparent_temperature)}°`;$('currentHumidity').textContent=`${c.relative_humidity_2m}%`;$('currentWind').textContent=`${Math.round(c.wind_speed_10m)} km/j`;$('currentRain').textContent=`${c.precipitation} mm`;$('rainSummary').textContent=c.precipitation>0?`${c.precipitation} mm terukur saat ini`:'Belum ada hujan terukur';$('updatedAt').textContent=`Data diperbarui ${time(c.time)}`;marker.setLatLng([selected.lat,selected.lon]).bindPopup(`<b>${selected.name}</b><br>${Math.round(c.temperature_2m)}°C · ${desc(c.weather_code)}`);renderForecast();renderChart();renderInsight();}
function upcoming(){let h=weather.hourly,now=new Date(weather.current.time),out=[];for(let i=0;i<h.time.length;i++)if(new Date(h.time[i])>=now&&out.length<6)out.push(i);return out;}
function renderForecast(){let h=weather.hourly,idx=upcoming();$('forecastList').innerHTML=idx.slice(0,5).map(i=>`<div class="hour-item"><small>${time(h.time[i])}</small><span>${icon(h.weather_code[i])}</span><b>${Math.round(h.temperature_2m[i])}°</b></div>`).join('');$('miniForecast').innerHTML=idx.slice(0,5).map(i=>`<div class="mini-row"><small>${time(h.time[i])}</small><span>${icon(h.weather_code[i])}</span><small>${desc(h.weather_code[i])}</small><b>${Math.round(h.temperature_2m[i])}°</b></div>`).join('');}
function renderChart(){let h=weather.hourly,idx=upcoming().slice(0,24),m=$('chartMetric').value,opts={temperature:{label:'Suhu °C',data:idx.map(i=>h.temperature_2m[i]),color:'#6ab8ff'},wind:{label:'Angin km/j',data:idx.map(i=>h.wind_speed_10m[i]),color:'#52dfc1'},rain:{label:'Hujan mm',data:idx.map(i=>h.precipitation[i]),color:'#ffc66b'}}[m];if(chart)chart.destroy();chart=new Chart($('forecastChart'),{type:'line',data:{labels:idx.map(i=>time(h.time[i])),datasets:[{data:opts.data,label:opts.label,borderColor:opts.color,backgroundColor:opts.color+'24',fill:true,tension:.36,pointRadius:2,borderWidth:2}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{x:{grid:{display:false},ticks:{color:'#a9bfdc',maxTicksLimit:5,font:{size:8}}},y:{grid:{color:'#ffffff15'},ticks:{color:'#a9bfdc',font:{size:8}},beginAtZero:m==='rain'}}}});}
function renderInsight(){let c=weather.current,h=weather.hourly,idx=h.time.findIndex(t=>t===c.time),chance=idx>=0?(h.precipitation_probability?.[idx]??0):0;let s=`Di ${selected.name}, kondisi saat ini ${desc(c.weather_code).toLowerCase()} dengan suhu ${Math.round(c.temperature_2m)}°C. Angin bertiup sekitar ${Math.round(c.wind_speed_10m)} km/j dan kelembapan mencapai ${c.relative_humidity_2m}%. `;s+=(c.precipitation>0||chance>=50)?`Perhatikan kemungkinan hujan${chance?` dengan peluang sekitar ${chance}%`:''}; siapkan payung bila akan beraktivitas di luar.`:'Data saat ini belum menunjukkan hujan terukur. Tetap periksa kembali prakiraan sebelum beraktivitas di luar ruangan.';$('insightText').textContent=s;$('tipText').textContent=chance>=50?'Peluang hujan cukup tinggi. Pertimbangkan membawa payung saat bepergian.':'Periksa kembali prakiraan cuaca sebelum beraktivitas di luar ruangan.';}
$('refreshBtn').addEventListener('click',()=>{loadWeather();scheduleMapFieldReload()});$('chartMetric').addEventListener('change',renderChart);
map.on('click',async e=>{setSelectedLocation({name:'Titik pilihan pada peta',lat:e.latlng.lat,lon:e.latlng.lng,zoom:map.getZoom(),source:'titik peta'});locationAccuracy=null;await loadWeather();scheduleMapFieldReload();const place=await reverseGeocode(e.latlng.lat,e.latlng.lng);if(place){selected.name=place;$('locationName').textContent=place;$('mapLocation').textContent=place;$('locationSub').textContent=`${selected.lat.toFixed(5)}°, ${selected.lon.toFixed(5)}° · Titik dipilih pada peta`;marker.bindPopup(`<b>${place}</b><br>Titik pilihan: ${selected.lat.toFixed(5)}, ${selected.lon.toFixed(5)}`);}});
async function search(){let q=$('citySearch').value.trim();if(!q)return;let box=$('searchResults');box.classList.remove('hidden');box.innerHTML='<button>Memuat lokasi...</button>';try{let r=await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(q)}&count=6&language=id&format=json`),d=await r.json();if(!d.results?.length){box.innerHTML='<button>Lokasi tidak ditemukan.</button>';return;}box.innerHTML=d.results.map((x,i)=>`<button data-i="${i}">${x.name}${x.admin1?', '+x.admin1:''}, ${x.country||''}</button>`).join('');box.querySelectorAll('[data-i]').forEach(b=>b.onclick=()=>{let x=d.results[+b.dataset.i];selected={name:x.name,lat:x.latitude,lon:x.longitude};locationAccuracy=null;map.setView([x.latitude,x.longitude],11);marker.setLatLng([x.latitude,x.longitude]);box.classList.add('hidden');map.setView([x.latitude,x.longitude],13);loadWeather();scheduleMapFieldReload();reverseGeocode(x.latitude,x.longitude).then(place=>{if(place){selected.name=place;$('locationName').textContent=place;$('mapLocation').textContent=place;$('locationSub').textContent=`${selected.lat.toFixed(5)}°, ${selected.lon.toFixed(5)}° · Lokasi hasil pencarian`;}});});}catch(e){box.innerHTML='<button>Pencarian gagal. Coba lagi.</button>';}}
$('searchBtn').addEventListener('click',search);$('citySearch').addEventListener('keydown',e=>{if(e.key==='Enter')search();});document.addEventListener('click',e=>{if(!e.target.closest('.search-wrap'))$('searchResults').classList.add('hidden');});
async function reverseGeocode(lat,lon){
  // Reverse geocoding supplies a human-readable administrative name; GPS coordinates remain authoritative.
  try{
    const r=await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${encodeURIComponent(lat)}&lon=${encodeURIComponent(lon)}&zoom=16&addressdetails=1&accept-language=id`);
    if(r.ok){
      const d=await r.json(),a=d.address||{};
      const village=a.village||a.suburb||a.neighbourhood||a.quarter||a.hamlet||a.town||a.city_district||a.city||a.municipality;
      const district=a.city_district||a.district||a.subdistrict;
      const city=a.city||a.town||a.municipality||a.county;
      const province=a.state;
      const parts=[];
      [village,district,city,province].forEach(v=>{if(v&&!parts.some(x=>x.toLowerCase()===v.toLowerCase()))parts.push(v)});
      if(parts.length)return parts.slice(0,4).join(', ');
      if(d.display_name)return d.display_name.split(',').slice(0,4).join(', ');
    }
  }catch(e){console.warn('Reverse geocoding OSM tidak tersedia:',e);}
  try{
    const r=await fetch(`https://geocoding-api.open-meteo.com/v1/reverse?latitude=${encodeURIComponent(lat)}&longitude=${encodeURIComponent(lon)}&language=id&format=json`);
    if(r.ok){const d=await r.json(),x=d?.results?.[0];if(x)return [x.name,x.admin2,x.admin1].filter((v,i,a)=>v&&a.indexOf(v)===i).join(', ');}
  }catch(e){console.warn('Reverse geocoding Open-Meteo tidak tersedia:',e);}
  return null;
}
function setSelectedLocation({name,lat,lon,accuracy=null,zoom=15,source='Lokasi dipilih'}){
  selected={name,lat:Number(lat),lon:Number(lon)};locationAccuracy=Number.isFinite(Number(accuracy))?Number(accuracy):null;
  map.setView([selected.lat,selected.lon],zoom,{animate:true});
  marker.setLatLng([selected.lat,selected.lon]).bindPopup(`<b>${selected.name}</b><br>${selected.lat.toFixed(5)}, ${selected.lon.toFixed(5)}${locationAccuracy!==null?`<br>Akurasi ±${Math.round(locationAccuracy)} m`:''}`);
  $('mapLocation').textContent=selected.name;
  $('mapCoords').textContent=`${selected.lat.toFixed(5)}°, ${selected.lon.toFixed(5)}°`;
  $('locationName').textContent=selected.name;
  $('locationSub').textContent=`${selected.lat.toFixed(5)}°, ${selected.lon.toFixed(5)}°${locationAccuracy!==null?` · GPS ±${Math.round(locationAccuracy)} m`:` · ${source}`}`;
}
function useCurrentLocation({quiet=false}={}){
  if(!('geolocation' in navigator)){if(!quiet)alert('Browser tidak mendukung geolokasi. Cari nama desa/kecamatan atau klik titik tepat pada peta.');return;}
  $('updatedAt').textContent='Mencari lokasi perangkat dengan akurasi tinggi…';
  // Request fresh high-accuracy readings several times and keep the most accurate fix.
  let best=null,attempt=0,finished=false;
  const finish=async()=>{
    if(finished)return;finished=true;
    if(!best){$('updatedAt').textContent='Lokasi perangkat tidak tersedia';if(!quiet)alert('Lokasi belum berhasil didapatkan. Izinkan akses lokasi untuk 127.0.0.1 di browser dan aktifkan Location Services Windows. Kamu juga bisa mencari nama desa atau klik langsung pada peta.');return;}
    const {lat,lon,accuracy}=best;
    setSelectedLocation({name:'Lokasi perangkat',lat,lon,accuracy,zoom:accuracy<=1000?16:(accuracy<=5000?13:10),source:'perkiraan perangkat'});
    $('updatedAt').textContent=accuracy<=1000?'Lokasi perangkat diperoleh':`Lokasi masih perkiraan (akurasi ±${Math.round(accuracy)} m)`;
    await loadWeather();scheduleMapFieldReload();
    const place=await reverseGeocode(lat,lon);
    if(place){selected.name=place;$('locationName').textContent=place;$('mapLocation').textContent=place;marker.bindPopup(`<b>${place}</b><br>${lat.toFixed(5)}, ${lon.toFixed(5)}${accuracy<=1000?`<br>GPS ±${Math.round(accuracy)} m`:`<br>Perkiraan perangkat ±${Math.round(accuracy)} m`}`);}
    $('locationSub').textContent=`${lat.toFixed(5)}°, ${lon.toFixed(5)}° · ${accuracy<=1000?'GPS':'Perkiraan lokasi'} ±${Math.round(accuracy)} m`;
    if(accuracy>5000){
      $('updatedAt').textContent=`Lokasi wilayah perkiraan · akurasi ±${Math.round(accuracy)} m`;
      if(!quiet)alert(`Perangkat hanya memberikan perkiraan lokasi dengan akurasi ±${Math.round(accuracy)} meter. Nama desa/kecamatan ditentukan dari koordinat perkiraan, jadi belum tentu tepat. Untuk titik yang lebih akurat, aktifkan Location Services/GPS atau klik lokasi kamu langsung pada peta.`);
    }
  };
  const ask=()=>{
    attempt++;
    navigator.geolocation.getCurrentPosition(p=>{
      const c=p.coords,fix={lat:Number(c.latitude),lon:Number(c.longitude),accuracy:Number(c.accuracy)};
      if(Number.isFinite(fix.lat)&&Number.isFinite(fix.lon)&&Number.isFinite(fix.accuracy)&&(!best||fix.accuracy<best.accuracy))best=fix;
      if((best&&best.accuracy<=1000)||attempt>=3){finish();return;}
      setTimeout(ask,800);
    },err=>{
      console.warn('Geolocation error:',err);
      if(attempt>=3){finish();return;}setTimeout(ask,700);
    },{enableHighAccuracy:true,timeout:18000,maximumAge:0});
  };
  ask();
}
$('locateBtn').addEventListener('click',()=>useCurrentLocation());
loadWeather();
// Try to center on the device location automatically on startup; the browser may ask permission.
setTimeout(()=>useCurrentLocation({quiet:true}),900);

// BMKG official open forecast API integration. This is village-level forecast data,
// not a gridded raster overlay; the map marker visualizes the selected administrative area.
let bmkgLayerMarker=null;
function flattenBmkgForecast(data){
  const groups=data?.data?.[0]?.cuaca || data?.cuaca || [];
  return groups.flat(Infinity).filter(x=>x && (x.local_datetime || x.utc_datetime || x.t));
}
async function loadBMKG(){
  const code=$('bmkgCode').value.trim();
  if(!code){$('bmkgStatus').textContent='Masukkan kode wilayah ADM4 BMKG.';return;}
  $('bmkgStatus').textContent='Mengambil prakiraan dari API BMKG...';
  $('bmkgForecast').innerHTML='';
  try{
    const response=await fetch(`https://api.bmkg.go.id/publik/prakiraan-cuaca?adm4=${encodeURIComponent(code)}`);
    if(!response.ok) throw new Error(`HTTP ${response.status}`);
    const data=await response.json();
    const rows=flattenBmkgForecast(data);
    if(!rows.length) throw new Error('Format data prakiraan tidak ditemukan untuk kode ini.');
    const loc=data?.lokasi || data?.data?.[0]?.lokasi || {};
    const place=loc.desa || loc.kecamatan || loc.kota || selected.name;
    $('bmkgStatus').textContent=`Sumber: BMKG · ${place} · ${rows.length} data prakiraan tersedia`;
    const items=rows.slice(0,5);
    $('bmkgForecast').innerHTML=items.map(x=>{
      const date=x.local_datetime||x.utc_datetime||'Waktu prakiraan';
      const temp=x.t!==undefined?`${x.t}°C`:'--°C';
      const wind=x.ws!==undefined?`${x.ws} km/j`:'-- km/j';
      const cloud=x.tcc!==undefined?`${x.tcc}%`:'--%';
      const rain=x.weather_desc||x.weather_desc_en||'Kondisi cuaca';
      return `<div class="bmkg-item"><span>${date}<br><small>${rain}</small></span><b>${temp}<br><small>Angin ${wind} · Awan ${cloud}</small></b></div>`;
    }).join('')+'<div class="bmkg-disclaimer">Sumber: BMKG. Prakiraan tingkat desa/kelurahan, bukan pengamatan real-time. Data dapat diperbarui oleh BMKG.</div>';
    const first=rows[0];
    if(first.t!==undefined){$('currentTemp').textContent=`${Math.round(Number(first.t))}°`;}
    if(first.ws!==undefined)$('currentWind').textContent=`${first.ws} km/j`;
    if(first.hu!==undefined)$('currentHumidity').textContent=`${first.hu}%`;
    if(first.weather_desc){$('condition').textContent=first.weather_desc;$('conditionShort').textContent=first.weather_desc;}
    if(first.weather_desc)$('insightText').textContent=`Prakiraan BMKG untuk ${place}: ${first.weather_desc}. Suhu ${first.t??'--'}°C, kecepatan angin ${first.ws??'--'} km/j, dan tutupan awan ${first.tcc??'--'}%. Periksa waktu prakiraan pada daftar di bawah.`;
    if(bmkgLayerMarker)map.removeLayer(bmkgLayerMarker);
    const color=activeLayer==='temperature'?'#ffb45e':activeLayer==='rain'?'#57b7ff':activeLayer==='clouds'?'#c7d4e8':'#53e3c2';
    bmkgLayerMarker=L.circleMarker([selected.lat,selected.lon],{radius:13,color:'#ffffff',weight:2,fillColor:color,fillOpacity:.85}).addTo(map).bindPopup(`<b>${place}</b><br>${first.weather_desc||'Prakiraan BMKG'}<br>Suhu: ${first.t??'--'}°C`);
    $('bmkgStatus').textContent+=` · Lapisan visual: ${activeLayer}`;
  }catch(err){
    $('bmkgStatus').textContent='Data BMKG belum berhasil dimuat. Periksa kode wilayah dan koneksi internet.';
    $('bmkgForecast').innerHTML='<div class="bmkg-disclaimer">Gunakan kode wilayah ADM4 yang valid. Lihat daftar kode dan format resmi pada portal Data Prakiraan Cuaca BMKG. Jika browser memblokir permintaan, integrasikan API melalui backend.</div>';
    console.error('BMKG API:',err);
  }
}
$('bmkgLoad').addEventListener('click',loadBMKG);



// Windy-inspired weather field: sampled forecast grid, smooth raster-style colors and data-driven particles.
animate=function(){}; // the weather-field renderer below owns the shared canvas.
let fieldPoints=[],baseFieldPoints=[],fieldBusy=false,fieldStamp=0,weatherDrops=[],timelineIndex=0,timelineTimer=null,temperaturePulse=0,lastFrame=0,refreshQueued=false;
const fieldCanvas=canvas,fieldCtx=ctx;
function overlayResize(){const r=fieldCanvas.getBoundingClientRect();fieldCanvas.width=Math.max(1,Math.floor(r.width*devicePixelRatio));fieldCanvas.height=Math.max(1,Math.floor(r.height*devicePixelRatio));fieldCtx.setTransform(devicePixelRatio,0,0,devicePixelRatio,0,0);weatherDrops=Array.from({length:activeLayer==='wind'?560:activeLayer==='rain'?100:activeLayer==='clouds'?150:0},()=>({x:Math.random()*r.width,y:Math.random()*r.height,age:Math.random()*100,seed:Math.random(),length:5+Math.random()*9}));}
function getPointValue(p,layer=activeLayer){if(layer==='temperature')return p.temperature_2m??25;if(layer==='rain')return p.precipitation??0;if(layer==='clouds')return p.cloud_cover??0;return p.wind_speed_10m??0}
let mapFieldTimer=null,lastGridFetch=0;
function scheduleMapFieldReload(){clearTimeout(mapFieldTimer);mapFieldTimer=setTimeout(()=>{if(Date.now()-lastGridFetch<45000){$('railSource').textContent='Memakai data peta tersimpan; pembaruan otomatis dibatasi agar API tidak terkena limit.';return}loadMapField()},900)}
async function loadMapField(){
 if(fieldBusy){refreshQueued=true;return}
 fieldBusy=true;lastGridFetch=Date.now();const stamp=++fieldStamp;
 const bounds=map.getBounds();
 const cacheKey=`ww-grid-${[bounds.getNorth(),bounds.getSouth(),bounds.getEast(),bounds.getWest()].map(v=>v.toFixed(1)).join('-')}`;
 $('railSource').textContent='Memuat titik cuaca...';
 try{
  const n=2,coords=[];
  for(let y=0;y<n;y++)for(let x=0;x<n;x++)coords.push({lat:bounds.getNorth()-(bounds.getNorth()-bounds.getSouth())*(y+.5)/n,lon:bounds.getWest()+(bounds.getEast()-bounds.getWest())*(x+.5)/n});
  const vars='temperature_2m,precipitation,weather_code,cloud_cover,wind_speed_10m,wind_direction_10m,relative_humidity_2m';
  const hourly='temperature_2m,precipitation_probability,precipitation,weather_code,cloud_cover,wind_speed_10m,wind_direction_10m,relative_humidity_2m';
  const latitudes=coords.map(p=>p.lat.toFixed(3)).join(','),longitudes=coords.map(p=>p.lon.toFixed(3)).join(',');
  const url=`https://api.open-meteo.com/v1/forecast?latitude=${encodeURIComponent(latitudes)}&longitude=${encodeURIComponent(longitudes)}&current=${vars}&hourly=${hourly}&forecast_days=1&timezone=Asia%2FJakarta`;
  let response,payload,lastError;
  for(let attempt=0;attempt<2;attempt++){
   try{response=await fetch(url);if(!response.ok)throw new Error(`Open-Meteo HTTP ${response.status}`);payload=await response.json();if(payload?.error)throw new Error(payload.reason||'API menolak permintaan');break}
   catch(err){lastError=err;if(attempt===0&&String(err.message).includes('429'))await new Promise(r=>setTimeout(r,1800));else if(attempt===0)await new Promise(r=>setTimeout(r,700));}
  }
  if(!payload)throw lastError||new Error('Tidak ada respons API');
  const list=Array.isArray(payload)?payload:[payload];
  const results=list.map(d=>d?.current&&d?.hourly?{lat:Number(d.latitude),lon:Number(d.longitude),...d.current,hourly:d.hourly}:null).filter(p=>p&&Number.isFinite(p.lat)&&Number.isFinite(p.lon));
  if(!results.length)throw new Error('Respons grid tidak berisi data valid');
  const unique=new Map();for(const p of results){const k=`${p.lat.toFixed(3)},${p.lon.toFixed(3)}`;if(!unique.has(k))unique.set(k,p)}
  if(stamp!==fieldStamp)return;
  baseFieldPoints=[...unique.values()];fieldPoints=baseFieldPoints.map(p=>({...p}));writeCache(cacheKey,baseFieldPoints);applyTimelineForecast();
  const rainCount=fieldPoints.filter(p=>shouldShowRainPoint(p)).length;
  $('railSource').textContent=`Grid Open-Meteo · ${fieldPoints.length} titik`;if(activeLayer==='rain')$('railSource').textContent+=rainCount?` · ${rainCount} titik hujan terindikasi`:' · tidak ada hujan terindikasi';else if(activeLayer==='wind')$('railSource').textContent+=' · angin mengikuti data';else if(activeLayer==='temperature')$('railSource').textContent+=' · suhu dari model';else if(activeLayer==='clouds')$('railSource').textContent+=' · tutupan awan dari model';
 }catch(e){
  console.error('Weather grid:',e);
  const cached=readCache(cacheKey);
  if(cached?.length){baseFieldPoints=cached;fieldPoints=baseFieldPoints.map(p=>({...p}));applyTimelineForecast();$('railSource').textContent=`Grid tersimpan · ${fieldPoints.length} titik (cache)`}
  else if(weather?.current){const p={lat:Number(selected.lat),lon:Number(selected.lon),...weather.current,hourly:weather.hourly};baseFieldPoints=[p];fieldPoints=[p];applyTimelineForecast();$('railSource').textContent=`Titik lokasi · ${weather._source||'data tersimpan'}; grid wilayah sementara tidak tersedia`; }
  else{$('railSource').textContent=`Data grid belum tersedia (${e.message||'koneksi'})`;}}
 finally{fieldBusy=false;if(refreshQueued){refreshQueued=false;loadMapField()}}
}
function interpolateColor(stops,v){if(v<=stops[0][0])return stops[0][1];for(let i=1;i<stops.length;i++){if(v<=stops[i][0]){const [a,ca]=stops[i-1],[b,cb]=stops[i],t=(v-a)/(b-a);return ca.map((c,j)=>Math.round(c+(cb[j]-c)*t))}}return stops[stops.length-1][1]}
function colorFor(v,layer=activeLayer){
 if(layer==='temperature')return interpolateColor([[0,[45,90,235]],[10,[55,165,255]],[18,[45,220,220]],[23,[70,210,130]],[27,[245,225,75]],[31,[255,150,55]],[35,[245,65,75]],[42,[190,35,100]]],Number(v)||0);
 if(layer==='rain')return interpolateColor([[.1,[70,155,255]],[1,[40,205,245]],[3,[40,220,150]],[8,[245,225,65]],[15,[255,145,45]],[30,[245,55,90]]],Math.max(.1,Number(v)||0));
 if(layer==='clouds')return [190,211,236];
 return interpolateColor([[0,[75,175,255]],[5,[60,220,195]],[15,[245,220,80]],[30,[255,150,65]],[60,[240,65,85]]],Number(v)||0);
}
function nearestFieldPoint(lat,lon){if(!fieldPoints.length)return null;let best=fieldPoints[0],dist=Infinity;for(const p of fieldPoints){const d=(p.lat-lat)**2*Math.cos(lat*Math.PI/180)**2+(p.lon-lon)**2;if(d<dist){dist=d;best=p}}return best}
function isRainWeatherCode(code){const c=Number(code);return (c>=51&&c<=67)||(c>=80&&c<=82)||c===95||c===96||c===99;}
function shouldShowRainPoint(p){
 const mm=Number(p.precipitation??0);if(!Number.isFinite(mm)||mm<0.1)return false;
 // Current view uses current conditions. Forecast timeline suppresses tiny model noise unless
 // probability or weather code also indicates precipitation.
 if(timelineIndex===0)return mm>=0.1 && (isRainWeatherCode(p.weather_code)||mm>=0.2);
 const probability=Number(p.precipitation_probability??0);
 return mm>=0.2 && (probability>=50||isRainWeatherCode(p.weather_code));
}
function drawRasterLayer(){
 // Rain is rendered as discrete forecast points below; avoid a misleading blurred heatmap.
 if(!fieldPoints.length)return;const w=fieldCanvas.clientWidth,h=fieldCanvas.clientHeight;
 if(activeLayer!=='rain'){
  fieldCtx.save();fieldCtx.globalCompositeOperation='source-over';fieldCtx.filter=activeLayer==='temperature'?'blur(20px)':activeLayer==='clouds'?'blur(17px)':'blur(13px)';
  const cellRadius=Math.max(27,Math.min(88,Math.min(w,h)/8.8));
  for(const p of fieldPoints){const pt=map.latLngToContainerPoint([p.lat,p.lon]);if(pt.x < -cellRadius*2 || pt.y < -cellRadius*2 || pt.x > w+cellRadius*2 || pt.y > h+cellRadius*2)continue;
   const v=Number(getPointValue(p));if(activeLayer==='clouds'&&v<8)continue;
   const c=colorFor(v),alpha=activeLayer==='clouds'?Math.min(.5,.08+v/230):activeLayer==='temperature'?.52:.44;
   const radius=cellRadius;const g=fieldCtx.createRadialGradient(pt.x,pt.y,0,pt.x,pt.y,radius);g.addColorStop(0,`rgba(${c[0]},${c[1]},${c[2]},${alpha})`);g.addColorStop(.55,`rgba(${c[0]},${c[1]},${c[2]},${alpha*.78})`);g.addColorStop(1,`rgba(${c[0]},${c[1]},${c[2]},0)`);fieldCtx.fillStyle=g;fieldCtx.beginPath();fieldCtx.arc(pt.x,pt.y,radius,0,Math.PI*2);fieldCtx.fill();
  }
  fieldCtx.restore();
 }
 // Temperature layer: subtle moving isotherm shimmer; temperature colors themselves remain tied to forecast values.
 if(activeLayer==='temperature'&&animationOn){temperaturePulse=(temperaturePulse+.012)%(Math.PI*2);fieldCtx.save();fieldCtx.filter='none';fieldCtx.lineWidth=1;for(const [i,p] of fieldPoints.entries()){if(i%2)continue;const pt=map.latLngToContainerPoint([p.lat,p.lon]);if(pt.x<0||pt.y<0||pt.x>w||pt.y>h)continue;const v=Number(p.temperature_2m);if(!Number.isFinite(v))continue;fieldCtx.strokeStyle=`rgba(255,255,255,${.10+.08*Math.sin(temperaturePulse+v)})`;fieldCtx.beginPath();fieldCtx.arc(pt.x,pt.y,7+2*Math.sin(temperaturePulse+v),0,Math.PI*2);fieldCtx.stroke();fieldCtx.fillStyle='rgba(7,22,42,.58)';fieldCtx.font='600 10px Inter,Arial';fieldCtx.textAlign='center';fieldCtx.fillText(`${Math.round(v)}°`,pt.x,pt.y-13)}fieldCtx.restore();}
 if(activeLayer==='rain'){
  // Discrete forecast markers: keep the basemap readable and prevent labels colliding.
  fieldCtx.save();fieldCtx.filter='none';fieldCtx.textAlign='center';fieldCtx.textBaseline='middle';
  const zoom=map.getZoom(),labelCandidates=[];
  for(const p of fieldPoints){
   const mm=Number(p.precipitation??0);
   if(!shouldShowRainPoint(p))continue;
   const pt=map.latLngToContainerPoint([p.lat,p.lon]);
   if(pt.x < -16||pt.y < -16||pt.x>w+16||pt.y>h+16)continue;
   const c=colorFor(mm,'rain'),col=`rgb(${c.join(',')})`;
   const r=Math.max(3.2,Math.min(5.8,2.9+Math.sqrt(mm)*.68));
   // Small halo plus a crisp center dot, located at the sampled forecast coordinate.
   fieldCtx.beginPath();fieldCtx.arc(pt.x,pt.y,r+3,0,Math.PI*2);fieldCtx.fillStyle=`rgba(${c.join(',')},.12)`;fieldCtx.fill();
   fieldCtx.beginPath();fieldCtx.arc(pt.x,pt.y,r,0,Math.PI*2);fieldCtx.fillStyle=col;fieldCtx.fill();
   fieldCtx.lineWidth=1.1;fieldCtx.strokeStyle='rgba(255,255,255,.96)';fieldCtx.stroke();
   // Show labels from the forecast value at a readable zoom; overlapping labels are skipped below.
   if(zoom>=7)labelCandidates.push({pt,mm,r});
  }
  fieldCtx.font='700 9px Inter,Arial';
  const occupied=[];
  // Prioritize higher precipitation; limit labels and skip any that overlap.
  labelCandidates.sort((a,b)=>b.mm-a.mm);
  for(const item of labelCandidates){
   if(occupied.length>=10)break;
   const label=`${item.mm.toLocaleString('id-ID',{maximumFractionDigits:1})} mm`,tw=fieldCtx.measureText(label).width+10;
   const box={x:item.pt.x-tw/2,y:item.pt.y-item.r-19,w:tw,h:14};
   if(occupied.some(b=>box.x<b.x+b.w+5&&box.x+box.w+5>b.x&&box.y<b.y+b.h+3&&box.y+box.h+3>b.y))continue;
   occupied.push(box);fieldCtx.fillStyle='rgba(4,20,42,.9)';fieldCtx.beginPath();fieldCtx.roundRect(box.x,box.y,box.w,box.h,4);fieldCtx.fill();
   fieldCtx.fillStyle='#fff';fieldCtx.fillText(label,item.pt.x,box.y+box.h/2);
  }
  fieldCtx.restore();
 }
}
function drawParticles(dt){const w=fieldCanvas.clientWidth,h=fieldCanvas.clientHeight,step=Math.max(.4,Math.min(1.8,dt/16.67));for(const p of weatherDrops){const ll=map.containerPointToLatLng([p.x,p.y]),d=nearestFieldPoint(ll.lat,ll.lng);if(!d)continue;
 if(activeLayer==='wind'&&animationOn){const dir=(Number(d.wind_direction_10m)||0)*Math.PI/180,speed=Number(d.wind_speed_10m)||0,spd=.15+Math.min(2.6,speed/16),vx=Math.sin(dir)*spd,vy=-Math.cos(dir)*spd;fieldCtx.strokeStyle=`rgba(220,246,255,${.26+Math.min(.55,speed/55)})`;fieldCtx.lineWidth=1.15;fieldCtx.beginPath();fieldCtx.moveTo(p.x,p.y);fieldCtx.lineTo(p.x+vx*p.length*step,p.y+vy*p.length*step);fieldCtx.stroke();p.x+=vx*2.3*step;p.y+=vy*2.3*step;}
 else if(activeLayer==='rain'&&animationOn&&shouldShowRainPoint(d)){const intensity=Number(d.precipitation),fall=(2+Math.min(5,intensity/2))*step;fieldCtx.strokeStyle=`rgba(190,229,255,${Math.min(.92,.38+intensity/24)})`;fieldCtx.lineWidth=1.25;fieldCtx.beginPath();fieldCtx.moveTo(p.x,p.y);fieldCtx.lineTo(p.x-1.8,p.y+5+Math.min(8,intensity));fieldCtx.stroke();p.y+=fall;p.x-=.45*step;}
 else if(activeLayer==='clouds'&&animationOn&&Number(d.cloud_cover??0)>=15){const cover=Number(d.cloud_cover);fieldCtx.fillStyle=`rgba(239,247,255,${.05+cover/900})`;fieldCtx.beginPath();fieldCtx.ellipse(p.x,p.y,12+cover/9,4+cover/22,0,0,Math.PI*2);fieldCtx.fill();p.x+=(.12+(Number(d.wind_speed_10m)||0)/100)*step;}
 if(p.x<0||p.x>w||p.y<0||p.y>h||Math.random()<.001){p.x=Math.random()*w;p.y=Math.random()*h;p.age=0}}
}
function renderWeatherField(ts=0){const w=fieldCanvas.clientWidth,h=fieldCanvas.clientHeight;if(w&&h){const dt=lastFrame?Math.min(40,ts-lastFrame):16.67;lastFrame=ts;fieldCtx.clearRect(0,0,w,h);if(fieldPoints.length){if(activeLayer!=='wind')drawRasterLayer();if(animationOn&&(activeLayer==='wind'||activeLayer==='rain'||activeLayer==='clouds'))drawParticles(dt)}}requestAnimationFrame(renderWeatherField)}
function setLayer(layer){activeLayer=layer;document.querySelectorAll('.rail-item').forEach(b=>b.classList.toggle('active',b.dataset.layer===layer));const labels={wind:['KECEPATAN ANGIN · km/j','Tenang','Kencang'],rain:['CURAH HUJAN · mm','Tidak hujan','Hujan lebat'],temperature:['SUHU UDARA · °C','Dingin','Panas'],clouds:['TUTUPAN AWAN · %','Cerah','Mendung']};$('legendTitle').textContent=labels[layer][0];$('legendLow').textContent=labels[layer][1];$('legendHigh').textContent=labels[layer][2];const grad={wind:'linear-gradient(90deg,#4bb5ff,#3bd9bd,#f5dc5c,#ff974e,#e64d75)',rain:'linear-gradient(90deg,#469bff,#28d0f0,#35dc8a,#ffe047,#ff963d,#f23f69)',temperature:'linear-gradient(90deg,#2d5aeb,#37a5ff,#2ddcda,#46d282,#f5e14b,#ff9637,#f5414b)',clouds:'linear-gradient(90deg,rgba(190,211,236,.05),rgba(190,211,236,.95))'};$('legendTitle').parentElement.querySelector('.legend-gradient').style.background=grad[layer];$('playWind').innerHTML=animationOn?'▶ <span>Animasi aktif</span>':'Ⅱ <span>Animasi mati</span>';overlayResize();}
document.querySelectorAll('.rail-item').forEach(b=>b.addEventListener('click',()=>setLayer(b.dataset.layer)));
$('playWind').addEventListener('click',()=>{animationOn=!animationOn;setLayer(activeLayer)});
map.on('moveend',scheduleMapFieldReload);map.on('zoomend',overlayResize);window.addEventListener('resize',()=>{overlayResize();map.invalidateSize();scheduleMapFieldReload()});
function applyTimelineForecast(){const baseTime=weather?.current?.time?new Date(weather.current.time):new Date();const target=new Date(baseTime.getTime()+timelineIndex*3600000);$('timelineTime').textContent=timelineIndex===0?'Data terkini':target.toLocaleString('id-ID',{weekday:'short',hour:'2-digit',minute:'2-digit'});$('timelineLabel').textContent=timelineIndex===0?'PRAKIRAAN SEKARANG':'PRAKIRAAN +'+timelineIndex+' JAM';if(baseFieldPoints.length){fieldPoints=baseFieldPoints.map(p=>{const h=p.hourly;if(timelineIndex===0||!h?.time?.length)return {...p};let idx=0,best=Infinity;for(let i=0;i<h.time.length;i++){const dt=Math.abs(new Date(h.time[i]).getTime()-target.getTime());if(dt<best){best=dt;idx=i}}return {...p,temperature_2m:h.temperature_2m?.[idx]??p.temperature_2m,precipitation:h.precipitation?.[idx]??p.precipitation,precipitation_probability:h.precipitation_probability?.[idx]??p.precipitation_probability,weather_code:h.weather_code?.[idx]??p.weather_code,cloud_cover:h.cloud_cover?.[idx]??p.cloud_cover,wind_speed_10m:h.wind_speed_10m?.[idx]??p.wind_speed_10m,wind_direction_10m:h.wind_direction_10m?.[idx]??p.wind_direction_10m,relative_humidity_2m:h.relative_humidity_2m?.[idx]??p.relative_humidity_2m}})}}
$('forecastTimeline').addEventListener('input',e=>{timelineIndex=Number(e.target.value);applyTimelineForecast()});
$('timelinePlay').addEventListener('click',()=>{if(timelineTimer){clearInterval(timelineTimer);timelineTimer=null;$('timelinePlay').textContent='▶';return}$('timelinePlay').textContent='Ⅱ';timelineTimer=setInterval(()=>{const slider=$('forecastTimeline');slider.value=(Number(slider.value)+1)%24;slider.dispatchEvent(new Event('input'))},1800)});
overlayResize();loadMapField();renderWeatherField();


// Nexora Wx AI assistant: generative answers via the secure backend /api/chat.
(()=>{
 const panel=document.getElementById('weatherChat'),launcher=document.getElementById('chatLauncher'),close=document.getElementById('chatClose'),form=document.getElementById('chatForm'),input=document.getElementById('chatInput'),messages=document.getElementById('chatMessages');
 if(!panel||!launcher||!form)return;
 const history=[];
 const open=()=>{panel.classList.add('chat-open');panel.setAttribute('aria-hidden','false');launcher.setAttribute('aria-expanded','true');setTimeout(()=>input.focus(),80)};
 const shut=()=>{panel.classList.remove('chat-open');panel.setAttribute('aria-hidden','true');launcher.setAttribute('aria-expanded','false');launcher.focus()};
 launcher.setAttribute('aria-expanded','false');launcher.addEventListener('click',()=>panel.classList.contains('chat-open')?shut():open());close.addEventListener('click',shut);document.addEventListener('keydown',e=>{if(e.key==='Escape'&&panel.classList.contains('chat-open'))shut()});
 function bubble(text,who){const el=document.createElement('div');el.className='chat-message '+who;el.textContent=text;if(who==='bot'){const stamp=document.createElement('small');stamp.textContent='Nexora AI · jawaban AI';el.appendChild(stamp)}messages.appendChild(el);messages.scrollTop=messages.scrollHeight}
 function currentContext(){
   const c=weather?.current;
   return {dashboardLocation:typeof selected!=='undefined'&&selected?{name:selected.name,latitude:selected.lat,longitude:selected.lon}:null,
     currentWeather:c?{time:c.time,temperature_c:c.temperature_2m,feels_like_c:c.apparent_temperature,humidity_percent:c.relative_humidity_2m,precipitation_mm:c.precipitation,weather_code:c.weather_code,wind_speed_kmh:c.wind_speed_10m,wind_direction_degrees:c.wind_direction_10m}:null,
     forecast:weather?.hourly?{time:weather.hourly.time?.slice(0,24),temperature_c:weather.hourly.temperature_2m?.slice(0,24),precipitation_probability_percent:weather.hourly.precipitation_probability?.slice(0,24),precipitation_mm:weather.hourly.precipitation?.slice(0,24),weather_code:weather.hourly.weather_code?.slice(0,24),wind_speed_kmh:weather.hourly.wind_speed_10m?.slice(0,24)}:null,
     selectedTimelineHour:typeof timelineIndex!=='undefined'?timelineIndex:0};
 }
 async function send(q){q=(q||'').trim();if(!q)return;bubble(q,'user');input.value='';history.push({role:'user',content:q});const wait=document.createElement('div');wait.className='chat-message bot chat-typing';wait.textContent='Nexora AI sedang menyusun jawaban…';messages.appendChild(wait);messages.scrollTop=messages.scrollHeight;
   try{
     const response=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({messages:history.slice(-12),weatherContext:currentContext()})});
     const data=await response.json().catch(()=>({}));
     wait.remove();
     if(!response.ok){const message=data.error||'Layanan AI belum tersedia.';bubble(message,'bot');return;}
     const reply=(data.answer||'Maaf, AI belum memberikan jawaban. Coba tulis ulang pertanyaanmu.').trim();history.push({role:'assistant',content:reply});bubble(reply,'bot');
   }catch(err){wait.remove();bubble('Nexora AI belum terhubung ke server AI. Jalankan website melalui server Node.js dan isi OPENAI_API_KEY pada file .env. Membuka index.html dengan Live Server saja tidak cukup untuk fitur AI generatif.','bot');}
 }
 form.addEventListener('submit',e=>{e.preventDefault();send(input.value)});panel.querySelectorAll('[data-question]').forEach(b=>b.addEventListener('click',()=>send(b.dataset.question)));
})();
