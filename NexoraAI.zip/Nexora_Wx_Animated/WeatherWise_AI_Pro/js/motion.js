/* Scroll-reveal and subtle interaction motion for Nexora Wx.
   Weather visualizations remain in app.js and continue to use live API values. */
(() => {
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const targets = [
    ['.rail', 'from-left'],
    ['.welcome-row', ''],
    ['.map-card', ''],
    ['.forecast-grid', ''],
    ['.current-card', 'from-right'],
    ['.week-card', 'from-right'],
    ['.tip-card', 'from-right']
  ];
  const elements = [];
  targets.forEach(([selector, direction]) => {
    document.querySelectorAll(selector).forEach(el => {
      if (!elements.includes(el)) {
        el.classList.add('motion-reveal');
        if (direction) el.classList.add(direction);
        elements.push(el);
      }
    });
  });

  if (reduceMotion || !('IntersectionObserver' in window)) {
    elements.forEach(el => el.classList.add('is-visible'));
    return;
  }

  document.documentElement.classList.add('motion-ready');
  elements.forEach((el, index) => el.style.setProperty('--motion-delay', `${Math.min(index * 65, 260)}ms`));

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.08, rootMargin: '0px 0px -24px 0px' });

  elements.forEach(el => observer.observe(el));

  // Add a gentle pointer-following highlight to larger cards, without moving map controls.
  const cards = document.querySelectorAll('.panel, .current-card, .tip-card');
  cards.forEach(card => {
    card.addEventListener('pointermove', event => {
      if (event.pointerType !== 'mouse') return;
      const rect = card.getBoundingClientRect();
      card.style.setProperty('--pointer-x', `${event.clientX - rect.left}px`);
      card.style.setProperty('--pointer-y', `${event.clientY - rect.top}px`);
    }, { passive: true });
  });

  document.addEventListener('visibilitychange', () => {
    // Keep the motion layer lightweight while the browser tab is in the background.
    document.documentElement.classList.toggle('tab-inactive', document.hidden);
  });
})();
