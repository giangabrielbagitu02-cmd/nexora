# Nexora Wx — Data Recovery Update

## Perbaikan pada versi ini
- Jika Open-Meteo mengembalikan HTTP 429 atau gagal, dashboard mencoba sumber cuaca cadangan wttr.in.
- Data cuaca terakhir yang tersimpan tetap digunakan saat API sementara tidak tersedia.
- Permintaan grid peta dikurangi menjadi 4 titik sampel dan pembaruan otomatis dibatasi agar tidak terus-menerus menabrak batas API.
- Jika grid tidak bisa dimuat tetapi data lokasi tersedia, peta menggunakan satu titik di koordinat lokasi yang dipilih. Aplikasi tidak membuat titik hujan palsu di area lain.
- Animasi angin, hujan, dan awan berjalan berdasarkan titik/data yang benar-benar berhasil diterima.
- Integrasi prakiraan BMKG tetap tersedia lewat kode wilayah ADM4 pada panel kanan. BMKG menyediakan prakiraan per desa/kelurahan, bukan grid cuaca nasional penuh.

## Cara menjalankan
1. Ekstrak folder `Nexora Wx_AI_Pro`.
2. Buka folder di Visual Studio Code.
3. Jalankan `index.html` melalui Live Server, bukan dengan membuka file secara langsung.
4. Jika data tidak langsung muncul, tekan **Perbarui** sekali dan tunggu beberapa detik. Hindari menekan tombol berulang kali.
5. Untuk prakiraan resmi BMKG, masukkan kode ADM4 desa/kelurahan yang sesuai lalu tekan **Ambil data BMKG**.

## Catatan sumber data
- Open-Meteo adalah sumber utama untuk kondisi cuaca dan grid peta.
- wttr.in hanya sumber cadangan agar dashboard tidak kosong ketika API utama membatasi permintaan.
- Prakiraan administratif BMKG dimuat terpisah dengan kode ADM4. Nilai dari sumber berbeda dapat memiliki waktu pembaruan dan resolusi yang berbeda; sumber ditampilkan agar tidak menyesatkan.
- Browser tidak dapat memaksa layanan eksternal melewati limit, CORS, atau gangguan jaringan. Jika sumber utama dan cadangan sama-sama tidak tersedia, aplikasi akan menyatakan data gagal alih-alih mengarang nilai.


## Pembaruan animasi Nexora Wx
Animasi antarmuka terinspirasi dari referensi video: elemen masuk dengan transisi halus saat terlihat, kartu memiliki efek hover dan highlight yang lembut, serta latar memiliki cahaya atmosferik yang bergerak perlahan. Warna dan komponen utama Nexora Wx tetap dipertahankan agar informasi cuaca mudah dibaca.

Animasi cuaca pada peta tetap dikelola oleh `js/app.js` dan menggunakan data yang berhasil diterima aplikasi. File tambahan `js/motion.js` hanya menangani gerakan antarmuka; file ini tidak membuat atau mengganti data cuaca.

### Menjalankan di Visual Studio Code
1. Ekstrak `Nexora_Wx_Animated.zip`.
2. Buka folder `WeatherWise_AI_Pro` melalui Visual Studio Code.
3. Pasang ekstensi **Live Server** jika belum tersedia.
4. Klik kanan `index.html`, lalu pilih **Open with Live Server**.
5. Pastikan koneksi internet aktif agar Leaflet, Chart.js, font, peta OpenStreetMap, dan layanan data cuaca dapat dimuat.
6. Untuk mengurangi gerakan, aktifkan preferensi **Reduce motion** pada pengaturan aksesibilitas sistem/peramban. Animasi antarmuka akan menyesuaikan preferensi tersebut.

Catatan: video referensi menampilkan portofolio berwarna merah gelap dengan transisi elemen, efek cahaya atmosferik, dan interaksi kartu. Efek gerak tersebut diadaptasi untuk dashboard cuaca; struktur dan palet inti Nexora Wx tetap dipertahankan, bukan menyalin tampilan portofolio secara literal.


## Asisten Chat Informasi Cuaca

Website memiliki panel **Tanya AI Cuaca** di kanan bawah. Pengunjung dapat bertanya tentang cuaca saat ini, suhu, kelembapan, angin, hujan, dan prakiraan beberapa jam ke depan. Jawaban dibentuk dari data cuaca yang sudah dimuat oleh dashboard; panel ini tidak memerlukan API key AI eksternal dan tidak mengarang kondisi jika data belum tersedia. Untuk model bahasa AI generatif sungguhan, diperlukan backend aman dan API key yang tidak ditaruh di frontend.

## Nexora AI generatif (perlu API key)
Versi ini menghubungkan panel chat ke model AI generatif melalui backend Node.js. AI dapat menjawab pertanyaan bebas, bukan hanya pertanyaan yang cocok dengan daftar kata tertentu. Untuk pertanyaan tentang cuaca terkini/lokasi lain dan informasi yang berubah, backend mengaktifkan web search pada Responses API. Data dashboard ikut dikirim sebagai konteks tambahan; AI diinstruksikan agar tidak memaksakan lokasi peta jika pengguna menanyakan tempat lain.

### Persiapan
1. Pasang Node.js versi LTS.
2. Buka folder `WeatherWise_AI_Pro` di terminal VS Code.
3. Jalankan `npm install`.
4. Salin `.env.example` menjadi `.env`.
5. Buat API key di dashboard OpenAI API, lalu isi `OPENAI_API_KEY` di `.env`. API key tidak boleh dimasukkan ke `app.js` atau `index.html`.
6. Jalankan `npm start`.
7. Buka `http://localhost:3000` di browser. Jangan gunakan Live Server untuk menjalankan fitur chat AI karena Live Server tidak menjalankan backend `/api/chat`.

### Catatan
- Penggunaan AI API memerlukan koneksi internet, API key aktif, dan kuota/billing API yang tersedia. Langganan ChatGPT tidak otomatis mencakup penggunaan API.
- Untuk deployment, jalankan backend di server HTTPS dan simpan `OPENAI_API_KEY` sebagai environment variable pada server. Jangan pernah membagikan file `.env`.
- Web search membantu mencari informasi terkini, tetapi tidak menjamin setiap hasil web benar atau selalu tersedia. AI diminta membedakan fakta terverifikasi dari ketidakpastian dan tidak mengarang data cuaca.
- Endpoint chat diberi batas permintaan dasar; untuk penggunaan publik, tambahkan autentikasi, pemantauan biaya, dan batas pemakaian sesuai kebutuhan.
